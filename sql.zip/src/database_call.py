import mysql.connector




tabel_names = ['stocks_data','rawtabel','stocks_list']




def get_existed_stock_names():

    db_connection = mysql.connector.connect(
        host = 'localhost',
        port = '3307',
        user = 'root',
        password = 'Saran@123',
        database = 'nse_sme_announcements'
    )

    cursor = db_connection.cursor()

    get_stock_name = f"""

        select id,symbol from {tabel_names[2]}

    """

    cursor.execute(get_stock_name)

    stock_name_data = cursor.fetchall()

    cursor.close()

    db_connection.close()
    

    return stock_name_data

# print(get_existed_stock_names())


def insert_stock_list_data(insert_data):

    db_connection = mysql.connector.connect(
        host = 'localhost',
        port = '3307',
        user = 'root',
        password = 'Saran@123',
        database = 'nse_sme_announcements'
    )

    cursor = db_connection.cursor()

    insert_stock_name = """

        insert into stocks_list(symbol,stock_name)
        value (%s,%s)

    """

    cursor.execute(insert_stock_name,insert_data[0])

    print("Rows created:", cursor.rowcount)

    cursor.close()

    db_connection.commit()

    db_connection.close()
    
