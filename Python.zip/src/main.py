import mysql.connector

from list import p1_list

connection = mysql.connector.connect(
    host='localhost',
    port='3307',
    user='root',
    password='Saran@123',
    database='nse_sme_announcements'
)

cursor = connection.cursor()

round_value = int(input('Enter the round number: '))

query = """

    select * from rawTabel
    # where round_value = %s

"""


cursor.execute(query)
rows = cursor.fetchall()

for i in rows:
    print(type(i))

print(rows)


cursor.close()

connection.close()

sme_announcement_api_1day = 'https://www.nseindia.com/api/corporate-announcements?index=sme&from_date=15-10-2026&to_date=16-10-2026&reqXbrl=false'
Equite_api_1day = 'https://www.nseindia.com/api/corporate-announcements?index=equities&from_date=15-10-2026&to_date=16-10-2026&reqXbrl=false'

sql = 'https://chatgpt.com/share/6ad22134-0b3c-83ec-b076-81ea715cb44f'
python = 'https://chatgpt.com/share/6ad22161-5644-83ee-a469-6f59600941b4'


# drop database if exists nse_sme_announcements;

# create database nse_sme_announcements;

# use nse_sme_announcements;

# create table rawTabel(
# 	id int primary key not null unique,
#     annoucement_date date,
#     file_url varchar(2001),
#     file_text varchar(2000),
#     subject varchar(500),
#     file_size varchar(100),
#     stock_name varchar(500),
#     symbol varchar(200)
# );